/** Automatically generated file. DO NOT MODIFY */
package com.lakj.comspace.simpleclientserverchatapp;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}
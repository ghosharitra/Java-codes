# Android Client-Server Chat Application
This is a simple Android chat application which communicate with a Java server program.  
Visit following link to read the full tutorial.  
http://lakjeewa.blogspot.com/2015/01/android-client-server-chat-application.html
